import tkinter
from tkinter import messagebox
import time
canvasWidth = 1440
canvasHeight = 720
screen = tkinter.Tk()
canvas = tkinter.Canvas(screen, width=canvasWidth, height=canvasHeight, background="white")
canvas.pack(fill="both", expand=True)
openedWindow = True
x = 720
y = 360
dx = 10
dy = 10
rect = canvas.create_rectangle(x,y,x,y,width=20,fill="red")
def game():
    if openedWindow == True:
        mouve()
        screen.update()
        
leftKey = 0
rightKey = 0
def when_key_pressed(event):
    global leftKey, rightKey
    if event.keysym == "Left":
        leftKey = 1
    elif event.keysym == "Right":
        rightKey = 1
def when_key_unpressed(event):
    global leftKey, rightKey
    if event.keysym == "Left":
        leftKey = 0
    elif event.keysym == "Right":
        rightKey = 0
def mouve():
    global x, y

    canvas.coords(rect,x,y,x,y)

    if leftKey==1:
        x=x-dx
    elif rightKey==1:
        x=x+dx

    canvas.after(50, mouve)

    return
    
def close():
    global openedWindow
    openedWindow = False
    screen.destroy()
screen.protocol("WM_DELETE_WINDOW", close)
screen.bind("<KeyPress>", when_key_pressed)
screen.bind("<KeyRelease>", when_key_unpressed)
game()

    
