import time
import pygame
pygame.init()
print("Bienvenue chez le minuteur !")
temps = float(input("Entrez un nombre à attendre en heure : "))
temps_heures = temps * 3600
minuterie = pygame.mixer.Sound("ZOOM0002.mp3")
time.sleep(temps_heures)
minuterie.play()
