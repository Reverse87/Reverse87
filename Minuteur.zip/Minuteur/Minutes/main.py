import time
import pygame
pygame.init()
print("Bienvenue chez le minuteur !")
temps = float(input("Entrez un nombre à attendre en minutes : "))
temps_minutes = temps * 60
minuterie = pygame.mixer.Sound("ZOOM0002.mp3")
time.sleep(temps_minutes)
minuterie.play()
