import time
import pygame
pygame.init()
print("Bienvenue chez le minuteur !")
temps = float(input("Entrez un nombre à attendre en secondes : "))
minuterie = pygame.mixer.Sound("ZOOM0002.mp3")
time.sleep(temps)
minuterie.play()
