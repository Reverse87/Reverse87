import time
import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((1440, 720))
pygame.display.set_caption("Kirby game")
eta = pygame.time.Clock()
font = pygame.font.Font(None, 70)

player = pygame.image.load('player.png').convert_alpha()
player_anim_x = 30
player_anim_y = 404
sky = pygame.image.load('sky.png').convert()
ground = pygame.image.load('ground.png').convert_alpha()
void = pygame.image.load('void.png').convert_alpha()
door_exit = pygame.image.load('door_exit.png').convert_alpha()
text = font.render('a', False, 'Red')

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player_anim_x = player_anim_x - 20
            elif event.key == pygame.K_RIGHT:
                player_anim_x = player_anim_x + 20
            elif event.key == pygame.K_UP:
                player_anim_y = player_anim_y - 204
            elif event.key == pygame.K_DOWN:
                player_anim_y = player_anim_y + 204
    screen.blit(sky, (0, 0))
    screen.blit(ground, (0, 500))
    screen.blit(ground, (10, 500))
    screen.blit(ground, (20, 500))
    screen.blit(ground, (30, 500))
    screen.blit(ground, (40, 500))
    screen.blit(ground, (50, 500))
    screen.blit(ground, (60, 500))
    screen.blit(ground, (70, 500))
    screen.blit(ground, (80, 500))
    screen.blit(ground, (90, 500))
    screen.blit(ground, (100, 500))
    screen.blit(ground, (110, 500))
    screen.blit(ground, (120, 500))
    screen.blit(ground, (130, 500))
    screen.blit(ground, (140, 500))
    screen.blit(ground, (150, 500))
    screen.blit(ground, (160, 500))
    screen.blit(ground, (170, 500))
    screen.blit(ground, (180, 500))
    screen.blit(ground, (190, 500))
    screen.blit(ground, (200, 500))
    screen.blit(void, (210, 500))
    screen.blit(void, (220, 500))
    screen.blit(void, (230, 500))
    screen.blit(void, (240, 500))
    screen.blit(void, (250, 500))
    screen.blit(void, (260, 500))
    screen.blit(void, (270, 500))
    screen.blit(void, (280, 500))
    screen.blit(void, (290, 500))
    screen.blit(void, (300, 500))
    screen.blit(void, (310, 500))
    screen.blit(void, (320, 500))
    screen.blit(void, (330, 500))
    screen.blit(void, (340, 500))
    screen.blit(void, (350, 500))
    screen.blit(void, (360, 500))
    screen.blit(void, (370, 500))
    screen.blit(void, (380, 500))
    screen.blit(void, (390, 500))
    screen.blit(ground, (400, 500))
    screen.blit(ground, (410, 500))
    screen.blit(ground, (420, 500))
    screen.blit(ground, (430, 500))
    screen.blit(ground, (440, 500))
    screen.blit(ground, (450, 500))
    screen.blit(ground, (460, 500))
    screen.blit(ground, (470, 500))
    screen.blit(ground, (480, 500))
    screen.blit(ground, (490, 500))
    screen.blit(ground, (500, 500))
    screen.blit(ground, (510, 500))
    screen.blit(ground, (520, 500))
    screen.blit(ground, (530, 500))
    screen.blit(ground, (540, 500))
    screen.blit(ground, (550, 500))
    screen.blit(ground, (560, 500))
    screen.blit(ground, (570, 500))
    screen.blit(ground, (580, 500))
    screen.blit(ground, (590, 500))
    screen.blit(ground, (600, 500))
    screen.blit(ground, (610, 500))
    screen.blit(ground, (620, 500))
    screen.blit(ground, (630, 500))
    screen.blit(ground, (640, 500))
    screen.blit(ground, (650, 500))
    screen.blit(ground, (660, 500))
    screen.blit(ground, (670, 500))
    screen.blit(ground, (680, 500))
    screen.blit(ground, (690, 500))
    screen.blit(ground, (700, 500))
    screen.blit(void, (710, 500))
    screen.blit(void, (720, 500))
    screen.blit(void, (730, 500))
    screen.blit(void, (740, 500))
    screen.blit(void, (750, 500))
    screen.blit(void, (760, 500))
    screen.blit(void, (770, 500))
    screen.blit(void, (780, 500))
    screen.blit(void, (790, 500))
    screen.blit(void, (800, 500))
    screen.blit(void, (810, 500))
    screen.blit(void, (820, 500))
    screen.blit(void, (830, 500))
    screen.blit(void, (840, 500))
    screen.blit(void, (850, 500))
    screen.blit(void, (860, 500))
    screen.blit(void, (870, 500))
    screen.blit(void, (880, 500))
    screen.blit(void, (890, 500))
    screen.blit(ground, (900, 500))
    screen.blit(ground, (910, 500))
    screen.blit(ground, (920, 500))
    screen.blit(ground, (930, 500))
    screen.blit(ground, (940, 500))
    screen.blit(ground, (950, 500))
    screen.blit(void, (960, 500))
    screen.blit(void, (970, 500))
    screen.blit(void, (980, 500))
    screen.blit(void, (990, 500))
    screen.blit(void, (1000, 500))
    screen.blit(void, (1010, 500))
    screen.blit(void, (1020, 500))
    screen.blit(void, (1030, 500))
    screen.blit(void, (1040, 500))
    screen.blit(void, (1050, 500))
    screen.blit(ground, (1060, 500))
    screen.blit(ground, (1070, 500))
    screen.blit(ground, (1080, 500))
    screen.blit(ground, (1090, 500))
    screen.blit(ground, (1100, 500))
    screen.blit(ground, (1110, 500))
    screen.blit(ground, (1120, 500))
    screen.blit(ground, (1130, 500))
    screen.blit(ground, (1140, 500))
    screen.blit(ground, (1150, 500))
    screen.blit(ground, (1160, 500))
    screen.blit(ground, (1170, 500))
    screen.blit(ground, (1180, 500))
    screen.blit(ground, (1190, 500))
    screen.blit(void, (1200, 500))
    screen.blit(void, (1210, 500))
    screen.blit(void, (1220, 500))
    screen.blit(void, (1230, 500))
    screen.blit(void, (1240, 500))
    screen.blit(void, (1250, 500))
    screen.blit(ground, (1260, 500))
    screen.blit(ground, (1270, 500))
    screen.blit(ground, (1280, 500))
    screen.blit(ground, (1290, 500))
    screen.blit(ground, (1300, 500))
    screen.blit(ground, (1310, 500))
    screen.blit(ground, (1320, 500))
    screen.blit(ground, (1330, 500))
    screen.blit(ground, (1340, 500))
    screen.blit(ground, (1350, 500))
    screen.blit(ground, (1360, 500))
    screen.blit(ground, (1370, 500))
    screen.blit(ground, (1380, 500))
    screen.blit(ground, (1390, 500))
    screen.blit(ground, (1400, 500))
    screen.blit(player, (player_anim_x, player_anim_y))
    screen.blit(door_exit, (1288, 330))
    screen.blit(text, (0, 675))
    pygame.display.update()
    eta.tick(60)
    if player_anim_x == 210 and player_anim_y == 404:
        player_anim_y = player_anim_y + 200
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 220 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 230 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 240 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 250 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 260 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 270 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 280 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 290 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 300 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 310 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 320 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 330 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 340 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 350 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 360 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 370 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 380 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 710 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 720 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 730 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 740 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 750 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 760 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 770 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 780 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 790 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 800 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 810 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 820 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 830 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 840 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 850 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 860 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 870 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 880 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 960 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 970 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 980 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 990 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1000 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1010 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1020 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1030 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1040 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1200 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1210 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1220 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1230 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1240 and player_anim_y == 404:
        player_anim_y = player_anim_y + 220
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 1388 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1389 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1390 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1391 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1392 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1393 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1394 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1395 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1396 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1397 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1398 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1399 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    elif player_anim_x == 1400 and player_anim_y == 404:
        time.sleep(0.5)
        print("Vous avez gagné !")
        pygame.quit()
        exit()
    else:
        continue
