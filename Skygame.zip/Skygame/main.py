import time
import random
import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((1440, 720))
pygame.display.set_caption("Sky game")
eta = pygame.time.Clock()
font = pygame.font.Font(None, 70)
blue = (0, 0, 255)
screen.fill(blue) 

player = pygame.image.load('player.png').convert()
player_anim_x = 720
player_anim_y = 300
sky = pygame.image.load('sky.png').convert_alpha()
sky_anim = 0
enemy = pygame.image.load('enemy.png').convert_alpha()
enemy_coord_x = random.randint(1, 1440)
enemy_coord_x2 = random.randint(1, 1440)
enemy_coord_x3 = random.randint(1, 1440)
enemy_coord_x4 = random.randint(1, 1440)
enemy_coord_x5 = random.randint(1, 1440)
enemy_coord_x6 = random.randint(1, 1440)
enemy_coord_x7 = random.randint(1, 1440)
enemy_coord_x8 = random.randint(1, 1440)
enemy_coord_x9 = random.randint(1, 1440)
enemy_coord_x10 = random.randint(1, 1440)
enemy_coord_x11 = random.randint(1, 1440)
enemy_coord_x12 = random.randint(1, 1440)
enemy_coord_x13 = random.randint(1, 1440)
enemy_coord_x14 = random.randint(1, 1440)
enemy_coord_x15 = random.randint(1, 1440)
enemy_coord_x16 = random.randint(1, 1440)
enemy_coord_x17 = random.randint(1, 1440)
enemy_coord_x18 = random.randint(1, 1440)
enemy_coord_x19 = random.randint(1, 1440)
enemy_coord_x20 = random.randint(1, 1440)
enemy_coord_x21 = random.randint(1, 1440)
enemy_coord_x22 = random.randint(1, 1440)
enemy_coord_x23 = random.randint(1, 1440)
enemy_coord_x24 = random.randint(1, 1440)
enemy_coord_x25 = random.randint(1, 1440)
enemy_coord_x26 = random.randint(1, 1440)
enemy_coord_x27 = random.randint(1, 1440)
enemy_coord_x28 = random.randint(1, 1440)
enemy_coord_x29 = random.randint(1, 1440)
enemy_coord_x30 = random.randint(1, 1440)
enemy_coord_x31 = random.randint(1, 1440)
enemy_coord_x32 = random.randint(1, 1440)
enemy_coord_x33 = random.randint(1, 1440)
enemy_coord_x34 = random.randint(1, 1440)
enemy_coord_x35 = random.randint(1, 1440)
enemy_coord_x36 = random.randint(1, 1440)
enemy_coord_x37 = random.randint(1, 1440)
enemy_coord_x38 = random.randint(1, 1440)
enemy_coord_x39 = random.randint(1, 1440)
enemy_coord_x40 = random.randint(1, 1440)
enemy_coord_x41 = random.randint(1, 1440)
enemy_coord_x42 = random.randint(1, 1440)
enemy_coord_x43 = random.randint(1, 1440)
enemy_coord_x44 = random.randint(1, 1440)
enemy_coord_x45 = random.randint(1, 1440)
enemy_coord_x46 = random.randint(1, 1440)
enemy_coord_x47 = random.randint(1, 1440)
enemy_coord_x48 = random.randint(1, 1440)
enemy_coord_x49 = random.randint(1, 1440)
enemy_coord_x50 = random.randint(1, 1440)
enemy_coord_x51 = random.randint(1, 1440)
enemy_coord_x52 = random.randint(1, 1440)
enemy_coord_x53 = random.randint(1, 1440)
enemy_coord_x54 = random.randint(1, 1440)
enemy_coord_x55 = random.randint(1, 1440)
enemy_coord_x56 = random.randint(1, 1440)
enemy_coord_x57 = random.randint(1, 1440)
enemy_coord_x58 = random.randint(1, 1440)
enemy_coord_x59 = random.randint(1, 1440)
enemy_coord_x60 = random.randint(1, 1440)
enemy_coord_x61 = random.randint(1, 1440)
enemy_coord_x62 = random.randint(1, 1440)
enemy_coord_x63 = random.randint(1, 1440)
enemy_coord_x64 = random.randint(1, 1440)
enemy_coord_x65 = random.randint(1, 1440)
enemy_coord_x66 = random.randint(1, 1440)
enemy_coord_x67 = random.randint(1, 1440)
enemy_coord_x68 = random.randint(1, 1440)
enemy_coord_x69 = random.randint(1, 1440)
enemy_coord_x70 = random.randint(1, 1440)
enemy_coord_x71 = random.randint(1, 1440)
enemy_coord_x72 = random.randint(1, 1440)
enemy_coord_x73 = random.randint(1, 1440)
enemy_coord_x74 = random.randint(1, 1440)
enemy_coord_x75 = random.randint(1, 1440)
enemy_coord_x76 = random.randint(1, 1440)
enemy_coord_x77 = random.randint(1, 1440)
enemy_coord_x78 = random.randint(1, 1440)
enemy_coord_x79 = random.randint(1, 1440)
enemy_coord_x80 = random.randint(1, 1440)
enemy_coord_x81 = random.randint(1, 1440)
enemy_coord_x82 = random.randint(1, 1440)
enemy_coord_x83 = random.randint(1, 1440)
enemy_coord_x84 = random.randint(1, 1440)
enemy_coord_x85 = random.randint(1, 1440)
enemy_coord_x86 = random.randint(1, 1440)
enemy_coord_x87 = random.randint(1, 1440)
enemy_coord_x88 = random.randint(1, 1440)
enemy_coord_x89 = random.randint(1, 1440)
enemy_coord_x90 = random.randint(1, 1440)
enemy_coord_x91 = random.randint(1, 1440)
enemy_coord_x92 = random.randint(1, 1440)
enemy_coord_x93 = random.randint(1, 1440)
enemy_coord_x94 = random.randint(1, 1440)
enemy_coord_x95 = random.randint(1, 1440)
enemy_coord_x96 = random.randint(1, 1440)
enemy_coord_x97 = random.randint(1, 1440)
enemy_coord_x98 = random.randint(1, 1440)
enemy_coord_x99 = random.randint(1, 1440)
enemy_coord_x100 = random.randint(1, 1440)
enemy_coord_y = 200
enemy_coord_y2 = 170
enemy_coord_y3 = 140
enemy_coord_y4 = 110
enemy_coord_y5 = 80
enemy_coord_y6 = 50
enemy_coord_y7 = 20
enemy_coord_y8 = -10
enemy_coord_y9 = -40
enemy_coord_y10 = -70
enemy_coord_y11 = -100
enemy_coord_y12 = -130
enemy_coord_y13 = -160
enemy_coord_y14 = -190
enemy_coord_y15 = -220
enemy_coord_y16 = -250
enemy_coord_y17 = -280
enemy_coord_y18 = -310
enemy_coord_y19 = -340
enemy_coord_y20 = -370
enemy_coord_y21 = -400
enemy_coord_y22 = -430
enemy_coord_y23 = -460
enemy_coord_y24 = -490
enemy_coord_y25 = -520
enemy_coord_y26 = -450
enemy_coord_y27 = -480
enemy_coord_y28 = -510
enemy_coord_y29 = -540
enemy_coord_y30 = -570
enemy_coord_y31 = -600
enemy_coord_y32 = -630
enemy_coord_y33 = -660
enemy_coord_y34 = -690
enemy_coord_y35 = -720
enemy_coord_y36 = -750
enemy_coord_y37 = -780
enemy_coord_y38 = -810
enemy_coord_y39 = -840
enemy_coord_y40 = -870
enemy_coord_y41 = -900
enemy_coord_y42 = -930
enemy_coord_y43 = -960
enemy_coord_y44 = -990
enemy_coord_y45 = -1020
enemy_coord_y46 = -1050
enemy_coord_y47 = -1080
enemy_coord_y48 = -1110
enemy_coord_y49 = -1140
enemy_coord_y50 = -1170
enemy_coord_y51 = -1200
enemy_coord_y52 = -1230
enemy_coord_y53 = -1260
enemy_coord_y54 = -1290
enemy_coord_y55 = -1320
enemy_coord_y56 = -1350
enemy_coord_y57 = -1380
enemy_coord_y58 = -1410
enemy_coord_y59 = -1440
enemy_coord_y60 = -1470
enemy_coord_y61 = -1500
enemy_coord_y62 = -1530
enemy_coord_y63 = -1560
enemy_coord_y64 = -1590
enemy_coord_y65 = -1620
enemy_coord_y66 = -1650
enemy_coord_y67 = -1680
enemy_coord_y68 = -1710
enemy_coord_y69 = -1740
enemy_coord_y70 = -1770
enemy_coord_y71 = -1800
enemy_coord_y72 = -1830
enemy_coord_y73 = -1860
enemy_coord_y74 = -1890
enemy_coord_y75 = -1920
enemy_coord_y76 = -1950
enemy_coord_y77 = -1980
enemy_coord_y78 = -2010
enemy_coord_y79 = -2040
enemy_coord_y80 = -2070
enemy_coord_y81 = -2100
enemy_coord_y82 = -2130
enemy_coord_y83 = -2160
enemy_coord_y84 = -2190
enemy_coord_y85 = -2220
enemy_coord_y86 = -2250
enemy_coord_y87 = -2280
enemy_coord_y88 = -2310
enemy_coord_y89 = -2340
enemy_coord_y90 = -2370
enemy_coord_y91 = -2400
enemy_coord_y92 = -2430
enemy_coord_y93 = -2460
enemy_coord_y94 = -2490
enemy_coord_y95 = -2510
enemy_coord_y96 = -2540
enemy_coord_y97 = -2570
enemy_coord_y98 = -2600
enemy_coord_y99 = -2630
enemy_coord_y100 = -2660
door_exit = pygame.image.load('door_exit.png').convert_alpha()
text = font.render('a', False, 'Red')

while True:

    sky_anim = sky_anim + 2
    enemy_coord_y  = enemy_coord_y + 2
    enemy_coord_y2  = enemy_coord_y2 + 2
    enemy_coord_y3  = enemy_coord_y3 + 2
    enemy_coord_y4  = enemy_coord_y4 + 2
    enemy_coord_y5  = enemy_coord_y5 + 2
    enemy_coord_y6  = enemy_coord_y6 + 2
    enemy_coord_y7  = enemy_coord_y7 + 2
    enemy_coord_y8  = enemy_coord_y8 + 2
    enemy_coord_y9  = enemy_coord_y9 + 2
    enemy_coord_y10 = enemy_coord_y10 + 2
    enemy_coord_y11 = enemy_coord_y11 + 2
    enemy_coord_y12 = enemy_coord_y12 + 2
    enemy_coord_y13 = enemy_coord_y13 + 2
    enemy_coord_y14 = enemy_coord_y14 + 2
    enemy_coord_y15 = enemy_coord_y15 + 2
    enemy_coord_y16 = enemy_coord_y16 + 2
    enemy_coord_y17 = enemy_coord_y17 + 2
    enemy_coord_y18 = enemy_coord_y18 + 2
    enemy_coord_y19 = enemy_coord_y19 + 2
    enemy_coord_y20 = enemy_coord_y20 + 2
    enemy_coord_y21 = enemy_coord_y21 + 2
    enemy_coord_y22 = enemy_coord_y22 + 2
    enemy_coord_y23 = enemy_coord_y23 + 2
    enemy_coord_y24 = enemy_coord_y24 + 2
    enemy_coord_y25 = enemy_coord_y25 + 2
    enemy_coord_y26 = enemy_coord_y26 + 2
    enemy_coord_y27 = enemy_coord_y27 + 2
    enemy_coord_y28 = enemy_coord_y28 + 2
    enemy_coord_y29 = enemy_coord_y29 + 2
    enemy_coord_y30 = enemy_coord_y30 + 2
    enemy_coord_y31 = enemy_coord_y31 + 2
    enemy_coord_y32 = enemy_coord_y32 + 2
    enemy_coord_y33 = enemy_coord_y33 + 2
    enemy_coord_y34 = enemy_coord_y34 + 2
    enemy_coord_y35 = enemy_coord_y35 + 2
    enemy_coord_y36 = enemy_coord_y36 + 2
    enemy_coord_y37 = enemy_coord_y37 + 2
    enemy_coord_y38 = enemy_coord_y38 + 2
    enemy_coord_y39 = enemy_coord_y39 + 2
    enemy_coord_y40 = enemy_coord_y40 + 2
    enemy_coord_y41 = enemy_coord_y41 + 2
    enemy_coord_y42 = enemy_coord_y42 + 2
    enemy_coord_y43 = enemy_coord_y43 + 2
    enemy_coord_y44 = enemy_coord_y44 + 2
    enemy_coord_y45 = enemy_coord_y45 + 2
    enemy_coord_y46 = enemy_coord_y46 + 2
    enemy_coord_y47 = enemy_coord_y47 + 2
    enemy_coord_y48 = enemy_coord_y48 + 2
    enemy_coord_y49 = enemy_coord_y49 + 2
    enemy_coord_y50 = enemy_coord_y50 + 2
    enemy_coord_y51 = enemy_coord_y51 + 2
    enemy_coord_y52 = enemy_coord_y52 + 2
    enemy_coord_y53 = enemy_coord_y53 + 2
    enemy_coord_y54 = enemy_coord_y54 + 2
    enemy_coord_y55 = enemy_coord_y55 + 2
    enemy_coord_y56 = enemy_coord_y56 + 2
    enemy_coord_y57 = enemy_coord_y57 + 2
    enemy_coord_y58 = enemy_coord_y58 + 2
    enemy_coord_y59 = enemy_coord_y59 + 2
    enemy_coord_y60 = enemy_coord_y60 + 2
    enemy_coord_y61 = enemy_coord_y61 + 2
    enemy_coord_y62 = enemy_coord_y62 + 2
    enemy_coord_y63 = enemy_coord_y63 + 2
    enemy_coord_y64 = enemy_coord_y64 + 2
    enemy_coord_y65 = enemy_coord_y65 + 2
    enemy_coord_y66 = enemy_coord_y66 + 2
    enemy_coord_y67 = enemy_coord_y67 + 2
    enemy_coord_y68 = enemy_coord_y68 + 2
    enemy_coord_y69 = enemy_coord_y69 + 2
    enemy_coord_y70 = enemy_coord_y70 + 2
    enemy_coord_y71 = enemy_coord_y71 + 2
    enemy_coord_y72 = enemy_coord_y72 + 2
    enemy_coord_y73 = enemy_coord_y73 + 2
    enemy_coord_y74 = enemy_coord_y74 + 2
    enemy_coord_y75 = enemy_coord_y75 + 2
    enemy_coord_y76 = enemy_coord_y76 + 2
    enemy_coord_y77 = enemy_coord_y77 + 2
    enemy_coord_y78 = enemy_coord_y78 + 2
    enemy_coord_y79 = enemy_coord_y79 + 2
    enemy_coord_y80 = enemy_coord_y80 + 2
    enemy_coord_y81 = enemy_coord_y81 + 2
    enemy_coord_y82 = enemy_coord_y82 + 2
    enemy_coord_y83 = enemy_coord_y83 + 2
    enemy_coord_y84 = enemy_coord_y84 + 2
    enemy_coord_y85 = enemy_coord_y85 + 2
    enemy_coord_y86 = enemy_coord_y86 + 2
    enemy_coord_y87 = enemy_coord_y87 + 2
    enemy_coord_y88 = enemy_coord_y88 + 2
    enemy_coord_y89 = enemy_coord_y89 + 2
    enemy_coord_y90 = enemy_coord_y90 + 2
    enemy_coord_y91 = enemy_coord_y91 + 2
    enemy_coord_y92 = enemy_coord_y92 + 2
    enemy_coord_y93 = enemy_coord_y93 + 2
    enemy_coord_y94 = enemy_coord_y94 + 2
    enemy_coord_y95 = enemy_coord_y95 + 2
    enemy_coord_y96 = enemy_coord_y96 + 2
    enemy_coord_y97 = enemy_coord_y97 + 2
    enemy_coord_y98 = enemy_coord_y98 + 2
    enemy_coord_y99 = enemy_coord_y99 + 2
    enemy_coord_y100 = enemy_coord_y100 + 2
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player_anim_x = player_anim_x - 30
            elif event.key == pygame.K_RIGHT:
                player_anim_x = player_anim_x + 30
            elif event.key == pygame.K_UP:
                player_anim_y = player_anim_y - 100
            elif event.key == pygame.K_DOWN:
                player_anim_y = player_anim_y + 100
    screen.blit(sky, (0, sky_anim))
    screen.blit(enemy, (enemy_coord_x, enemy_coord_y))
    screen.blit(enemy, (enemy_coord_x2, enemy_coord_y2))
    screen.blit(enemy, (enemy_coord_x3, enemy_coord_y3))
    screen.blit(enemy, (enemy_coord_x4, enemy_coord_y4))
    screen.blit(enemy, (enemy_coord_x5, enemy_coord_y5))
    screen.blit(enemy, (enemy_coord_x6, enemy_coord_y6))
    screen.blit(enemy, (enemy_coord_x7, enemy_coord_y7))
    screen.blit(enemy, (enemy_coord_x8, enemy_coord_y8))
    screen.blit(enemy, (enemy_coord_x9, enemy_coord_y9))
    screen.blit(enemy, (enemy_coord_x10, enemy_coord_y10))
    screen.blit(enemy, (enemy_coord_x11, enemy_coord_y11))
    screen.blit(enemy, (enemy_coord_x12, enemy_coord_y12))
    screen.blit(enemy, (enemy_coord_x13, enemy_coord_y13))
    screen.blit(enemy, (enemy_coord_x14, enemy_coord_y14))
    screen.blit(enemy, (enemy_coord_x15, enemy_coord_y15))
    screen.blit(enemy, (enemy_coord_x16, enemy_coord_y16))
    screen.blit(enemy, (enemy_coord_x17, enemy_coord_y17))
    screen.blit(enemy, (enemy_coord_x18, enemy_coord_y18))
    screen.blit(enemy, (enemy_coord_x19, enemy_coord_y19))
    screen.blit(enemy, (enemy_coord_x20, enemy_coord_y20))
    screen.blit(enemy, (enemy_coord_x21, enemy_coord_y21))
    screen.blit(enemy, (enemy_coord_x22, enemy_coord_y22))
    screen.blit(enemy, (enemy_coord_x23, enemy_coord_y23))
    screen.blit(enemy, (enemy_coord_x24, enemy_coord_y24))
    screen.blit(enemy, (enemy_coord_x25, enemy_coord_y25))
    screen.blit(enemy, (enemy_coord_x26, enemy_coord_y26))
    screen.blit(enemy, (enemy_coord_x27, enemy_coord_y27))
    screen.blit(enemy, (enemy_coord_x28, enemy_coord_y28))
    screen.blit(enemy, (enemy_coord_x29, enemy_coord_y29))
    screen.blit(enemy, (enemy_coord_x30, enemy_coord_y30))
    screen.blit(enemy, (enemy_coord_x31, enemy_coord_y31))
    screen.blit(enemy, (enemy_coord_x32, enemy_coord_y32))
    screen.blit(enemy, (enemy_coord_x33, enemy_coord_y33))
    screen.blit(enemy, (enemy_coord_x34, enemy_coord_y34))
    screen.blit(enemy, (enemy_coord_x35, enemy_coord_y35))
    screen.blit(enemy, (enemy_coord_x36, enemy_coord_y36))
    screen.blit(enemy, (enemy_coord_x37, enemy_coord_y37))
    screen.blit(enemy, (enemy_coord_x38, enemy_coord_y38))
    screen.blit(enemy, (enemy_coord_x39, enemy_coord_y39))
    screen.blit(enemy, (enemy_coord_x40, enemy_coord_y40))
    screen.blit(enemy, (enemy_coord_x41, enemy_coord_y41))
    screen.blit(enemy, (enemy_coord_x42, enemy_coord_y42))
    screen.blit(enemy, (enemy_coord_x43, enemy_coord_y43))
    screen.blit(enemy, (enemy_coord_x44, enemy_coord_y44))
    screen.blit(enemy, (enemy_coord_x45, enemy_coord_y45))
    screen.blit(enemy, (enemy_coord_x46, enemy_coord_y46))
    screen.blit(enemy, (enemy_coord_x47, enemy_coord_y47))
    screen.blit(enemy, (enemy_coord_x48, enemy_coord_y48))
    screen.blit(enemy, (enemy_coord_x49, enemy_coord_y49))
    screen.blit(enemy, (enemy_coord_x50, enemy_coord_y50))
    screen.blit(enemy, (enemy_coord_x51, enemy_coord_y51))
    screen.blit(enemy, (enemy_coord_x52, enemy_coord_y52))
    screen.blit(enemy, (enemy_coord_x53, enemy_coord_y53))
    screen.blit(enemy, (enemy_coord_x54, enemy_coord_y54))
    screen.blit(enemy, (enemy_coord_x55, enemy_coord_y55))
    screen.blit(enemy, (enemy_coord_x56, enemy_coord_y56))
    screen.blit(enemy, (enemy_coord_x57, enemy_coord_y57))
    screen.blit(enemy, (enemy_coord_x58, enemy_coord_y58))
    screen.blit(enemy, (enemy_coord_x59, enemy_coord_y59))
    screen.blit(enemy, (enemy_coord_x60, enemy_coord_y60))
    screen.blit(enemy, (enemy_coord_x61, enemy_coord_y61))
    screen.blit(enemy, (enemy_coord_x62, enemy_coord_y62))
    screen.blit(enemy, (enemy_coord_x63, enemy_coord_y63))
    screen.blit(enemy, (enemy_coord_x64, enemy_coord_y64))
    screen.blit(enemy, (enemy_coord_x65, enemy_coord_y65))
    screen.blit(enemy, (enemy_coord_x66, enemy_coord_y66))
    screen.blit(enemy, (enemy_coord_x67, enemy_coord_y67))
    screen.blit(enemy, (enemy_coord_x68, enemy_coord_y68))
    screen.blit(enemy, (enemy_coord_x69, enemy_coord_y69))
    screen.blit(enemy, (enemy_coord_x70, enemy_coord_y70))
    screen.blit(enemy, (enemy_coord_x71, enemy_coord_y71))
    screen.blit(enemy, (enemy_coord_x72, enemy_coord_y72))
    screen.blit(enemy, (enemy_coord_x73, enemy_coord_y73))
    screen.blit(enemy, (enemy_coord_x74, enemy_coord_y74))
    screen.blit(enemy, (enemy_coord_x75, enemy_coord_y75))
    screen.blit(enemy, (enemy_coord_x76, enemy_coord_y76))
    screen.blit(enemy, (enemy_coord_x77, enemy_coord_y77))
    screen.blit(enemy, (enemy_coord_x78, enemy_coord_y78))
    screen.blit(enemy, (enemy_coord_x79, enemy_coord_y79))
    screen.blit(enemy, (enemy_coord_x80, enemy_coord_y80))
    screen.blit(enemy, (enemy_coord_x81, enemy_coord_y81))
    screen.blit(enemy, (enemy_coord_x82, enemy_coord_y82))
    screen.blit(enemy, (enemy_coord_x83, enemy_coord_y83))
    screen.blit(enemy, (enemy_coord_x84, enemy_coord_y84))
    screen.blit(enemy, (enemy_coord_x85, enemy_coord_y85))
    screen.blit(enemy, (enemy_coord_x86, enemy_coord_y86))
    screen.blit(enemy, (enemy_coord_x87, enemy_coord_y87))
    screen.blit(enemy, (enemy_coord_x88, enemy_coord_y88))
    screen.blit(enemy, (enemy_coord_x89, enemy_coord_y89))
    screen.blit(enemy, (enemy_coord_x90, enemy_coord_y90))
    screen.blit(enemy, (enemy_coord_x91, enemy_coord_y91))
    screen.blit(enemy, (enemy_coord_x92, enemy_coord_y92))
    screen.blit(enemy, (enemy_coord_x93, enemy_coord_y93))
    screen.blit(enemy, (enemy_coord_x94, enemy_coord_y94))
    screen.blit(enemy, (enemy_coord_x95, enemy_coord_y95))
    screen.blit(enemy, (enemy_coord_x96, enemy_coord_y96))
    screen.blit(enemy, (enemy_coord_x97, enemy_coord_y97))
    screen.blit(enemy, (enemy_coord_x98, enemy_coord_y98))
    screen.blit(enemy, (enemy_coord_x99, enemy_coord_y99))
    screen.blit(enemy, (enemy_coord_x100, enemy_coord_y100))
    screen.blit(door_exit, (720, -2800))
    screen.blit(player, (player_anim_x, player_anim_y))
    screen.blit(text, (0, 675))
    pygame.display.update()
    eta.tick(60)
    if player_anim_x == enemy_coord_x and player_anim_y == enemy_coord_y:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x2 and player_anim_y == enemy_coord_y2:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x3 and player_anim_y == enemy_coord_y3:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x4 and player_anim_y == enemy_coord_y4:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x5 and player_anim_y == enemy_coord_y5:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x6 and player_anim_y == enemy_coord_y6:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x7 and player_anim_y == enemy_coord_y7:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x8 and player_anim_y == enemy_coord_y8:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x9 and player_anim_y == enemy_coord_y9:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x10 and player_anim_y == enemy_coord_y10:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x11 and player_anim_y == enemy_coord_y11:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x12 and player_anim_y == enemy_coord_y12:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x13 and player_anim_y == enemy_coord_y13:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x14 and player_anim_y == enemy_coord_y14:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x15 and player_anim_y == enemy_coord_y15:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x16 and player_anim_y == enemy_coord_y16:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x17 and player_anim_y == enemy_coord_y17:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x18 and player_anim_y == enemy_coord_y18:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x19 and player_anim_y == enemy_coord_y19:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x20 and player_anim_y == enemy_coord_y20:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x21 and player_anim_y == enemy_coord_y21:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x22 and player_anim_y == enemy_coord_y22:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x23 and player_anim_y == enemy_coord_y23:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x24 and player_anim_y == enemy_coord_y24:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x25 and player_anim_y == enemy_coord_y25:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x26 and player_anim_y == enemy_coord_y26:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x27 and player_anim_y == enemy_coord_y27:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x28 and player_anim_y == enemy_coord_y28:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x29 and player_anim_y == enemy_coord_y29:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x30 and player_anim_y == enemy_coord_y30:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x31 and player_anim_y == enemy_coord_y31:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x32 and player_anim_y == enemy_coord_y32:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x33 and player_anim_y == enemy_coord_y33:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x34 and player_anim_y == enemy_coord_y34:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x35 and player_anim_y == enemy_coord_y35:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x36 and player_anim_y == enemy_coord_y36:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x37 and player_anim_y == enemy_coord_y37:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x38 and player_anim_y == enemy_coord_y38:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x39 and player_anim_y == enemy_coord_y39:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x40 and player_anim_y == enemy_coord_y40:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x41 and player_anim_y == enemy_coord_y41:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x42 and player_anim_y == enemy_coord_y42:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x43 and player_anim_y == enemy_coord_y43:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x44 and player_anim_y == enemy_coord_y44:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x45 and player_anim_y == enemy_coord_y45:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x46 and player_anim_y == enemy_coord_y46:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x47 and player_anim_y == enemy_coord_y47:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x48 and player_anim_y == enemy_coord_y48:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x49 and player_anim_y == enemy_coord_y49:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x50 and player_anim_y == enemy_coord_y50:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x51 and player_anim_y == enemy_coord_y51:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x52 and player_anim_y == enemy_coord_y52:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x53 and player_anim_y == enemy_coord_y53:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x54 and player_anim_y == enemy_coord_y54:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x55 and player_anim_y == enemy_coord_y55:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x56 and player_anim_y == enemy_coord_y56:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x57 and player_anim_y == enemy_coord_y57:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x58 and player_anim_y == enemy_coord_y58:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x59 and player_anim_y == enemy_coord_y59:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x60 and player_anim_y == enemy_coord_y60:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x61 and player_anim_y == enemy_coord_y61:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x62 and player_anim_y == enemy_coord_y62:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x63 and player_anim_y == enemy_coord_y63:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x64 and player_anim_y == enemy_coord_y64:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x65 and player_anim_y == enemy_coord_y65:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x66 and player_anim_y == enemy_coord_y66:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x67 and player_anim_y == enemy_coord_y67:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x68 and player_anim_y == enemy_coord_y68:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x69 and player_anim_y == enemy_coord_y69:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x70 and player_anim_y == enemy_coord_y70:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x71 and player_anim_y == enemy_coord_y71:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x72 and player_anim_y == enemy_coord_y72:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x73 and player_anim_y == enemy_coord_y73:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x74 and player_anim_y == enemy_coord_y74:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x75 and player_anim_y == enemy_coord_y75:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x76 and player_anim_y == enemy_coord_y76:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x77 and player_anim_y == enemy_coord_y77:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x78 and player_anim_y == enemy_coord_y78:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x79 and player_anim_y == enemy_coord_y79:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x80 and player_anim_y == enemy_coord_y80:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x81 and player_anim_y == enemy_coord_y81:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x82 and player_anim_y == enemy_coord_y82:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x83 and player_anim_y == enemy_coord_y83:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x84 and player_anim_y == enemy_coord_y84:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x85 and player_anim_y == enemy_coord_y85:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x86 and player_anim_y == enemy_coord_y86:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x87 and player_anim_y == enemy_coord_y87:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x88 and player_anim_y == enemy_coord_y88:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x89 and player_anim_y == enemy_coord_y89:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x90 and player_anim_y == enemy_coord_y90:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x91 and player_anim_y == enemy_coord_y91:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x92 and player_anim_y == enemy_coord_y92:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x93 and player_anim_y == enemy_coord_y93:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x94 and player_anim_y == enemy_coord_y94:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x95 and player_anim_y == enemy_coord_y95:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x96 and player_anim_y == enemy_coord_y96:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x97 and player_anim_y == enemy_coord_y97:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x98 and player_anim_y == enemy_coord_y98:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x99 and player_anim_y == enemy_coord_y99:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == enemy_coord_x100 and player_anim_y == enemy_coord_y100:
        break
        time.sleep(0.5)
        print("GAME OVER")
        pygame.quit()
        exit()
    elif player_anim_x == 720 and player_anim_y == -2800:
        break
        time.sleep(0.5)
        print("Tu as gagné !")
        pygame.quit()
        exit()
    else:
        continue
