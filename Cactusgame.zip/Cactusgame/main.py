import pygame
import random

def incrementeTime():
    global counter
    compteur=counter+1
    if counter<10:
        temp['text']="000"+str(counter)
    elif counter>=10 and compteur<100:
        temp['text']="00"+str(counter)
    elif counter>=100 and compteur<1000:
        temp['text']="0"+str(counter)
    else:
        temp['text']=str(counter)

    if flag:
        fen.after(150, incrementeTime)

pygame.init()

screen = pygame.display.set_mode((600, 300))
pygame.display.set_caption("Cactus game")
eta = pygame.time.Clock()
font = pygame.font.Font(None, 70)

player = pygame.image.load('1.png').convert_alpha()
player_anim_x = 40
player_anim_y = 174
background = pygame.image.load('background.png').convert()
back_anim = 0
line = pygame.image.load('line.png').convert_alpha()
line_anim = 10
obs = pygame.image.load('obs.png').convert_alpha()
cactus_anim_x = 200
cactus_anim_x2 = 400
cactus_anim_x3 = 600
cactus_anim_x4 = 800
cactus_anim_x5 = 1000
cactus_anim_x6 = 1200
cactus_anim_x7 = 1400
cactus_anim_x8 = 1800
cactus_anim_x9 = 2200
cactus_anim_x10 = 2400
cactus_anim_x11 = 2600
cactus_anim_x12 = 2800
cactus_anim_x13 = 3000
cactus_anim_x14 = 3200
cactus_anim_x15 = 3400
cactus_anim_x16 = 3600
cactus_anim_x17 = 3800
cactus_anim_x18 = 4000
cactus_anim_x19 = 4200
cactus_anim_x20 = 4400
text = font.render('a', False, 'Red')

while True:

    back_anim = back_anim - 2
    line_anim = line_anim - 2
    cactus_anim_x = cactus_anim_x - 2
    cactus_anim_x2 = cactus_anim_x2 - 2
    cactus_anim_x3 = cactus_anim_x3 - 2
    cactus_anim_x4 = cactus_anim_x4 - 2
    cactus_anim_x5 = cactus_anim_x5 - 2
    cactus_anim_x6 = cactus_anim_x6 - 2
    cactus_anim_x7 = cactus_anim_x7 - 2
    cactus_anim_x8 = cactus_anim_x8 - 2
    cactus_anim_x9 = cactus_anim_x9 - 2
    cactus_anim_x10 = cactus_anim_x10 - 2
    cactus_anim_x11 = cactus_anim_x11 - 2
    cactus_anim_x12 = cactus_anim_x12 - 2
    cactus_anim_x13 = cactus_anim_x13 - 2
    cactus_anim_x14 = cactus_anim_x14 - 2
    cactus_anim_x15 = cactus_anim_x15 - 2
    cactus_anim_x16 = cactus_anim_x16 - 2
    cactus_anim_x17 = cactus_anim_x17 - 2
    cactus_anim_x18 = cactus_anim_x18 - 2
    cactus_anim_x19 = cactus_anim_x19 - 2
    cactus_anim_x20 = cactus_anim_x20 - 2
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                player_anim_y = player_anim_y - 20
            elif event.key == pygame.K_DOWN:
                player_anim_y = player_anim_y + 20
    screen.blit(background, (back_anim, 0))
    screen.blit(line, (line_anim, 270))
    screen.blit(obs, (cactus_anim_x, 142))
    screen.blit(obs, (cactus_anim_x2, 142))
    screen.blit(obs, (cactus_anim_x3, 142))
    screen.blit(obs, (cactus_anim_x4, 142))
    screen.blit(obs, (cactus_anim_x5, 142))
    screen.blit(obs, (cactus_anim_x6, 142))
    screen.blit(obs, (cactus_anim_x7, 142))
    screen.blit(obs, (cactus_anim_x8, 142))
    screen.blit(obs, (cactus_anim_x9, 142))
    screen.blit(obs, (cactus_anim_x10, 142))
    screen.blit(obs, (cactus_anim_x11, 142))
    screen.blit(obs, (cactus_anim_x12, 142))
    screen.blit(obs, (cactus_anim_x13, 142))
    screen.blit(obs, (cactus_anim_x14, 142))
    screen.blit(obs, (cactus_anim_x15, 142))
    screen.blit(obs, (cactus_anim_x16, 142))
    screen.blit(obs, (cactus_anim_x17, 142))
    screen.blit(obs, (cactus_anim_x18, 142))
    screen.blit(obs, (cactus_anim_x19, 142))
    screen.blit(obs, (cactus_anim_x20, 142))
    screen.blit(player, (player_anim_x, player_anim_y))
    screen.blit(text, (0, 675))
    pygame.display.update()
    eta.tick(60)
