import time
import random
import pygame
from sys import exit

pygame.init()

screen = pygame.display.set_mode((600, 300))
pygame.display.set_caption("Cactus game")
eta = pygame.time.Clock()
font = pygame.font.Font(None, 70)

player = pygame.transform.scale(pygame.image.load('1.png'), (58, 96))
player_anim_x = 40
player_anim_y = 220
jumping = False
background = pygame.image.load('background.png').convert()
back_anim = 0
back_anim2 = -600
back_anim3 = -1200
back_anim4 = -1800
back_anim5 = -2400
back_anim6 = -3000
back_anim7 = -3600
back_anim8 = -4200
back_anim9 = -4800
back_anim10 = -5400
back_anim11 = -6000
back_anim12 = -6600
back_anim13 = -7200
back_anim14 = -7800
back_anim15 = -8400
back_anim16 = -9000
back_anim17 = -9600
back_anim18 = -10200
back_anim19 = -10800
back_anim20 = -11400
back_anim21 = -12000
back_anim22 = -12600
back_anim23 = -13200
back_anim24 = -13800
back_anim25 = -14400
back_anim26 = -15000
back_anim27 = -15600
back_anim28 = -16200
back_anim29 = -16800
back_anim30 = -17400
back_anim31 = -18000
back_anim32 = -18600
back_anim33 = -19200
back_anim34 = -19800
back_anim35 = -20400
back_anim36 = -21000
back_anim37 = -21600
back_anim38 = -22200
back_anim39 = -22800
back_anim40 = -23400
back_anim41 = -24000
back_anim42 = -24600
back_anim43 = -25200
back_anim44 = -25800
back_anim45 = -26400
back_anim46 = -27000
back_anim47 = -27600
back_anim48 = -28200
back_anim49 = -28800
back_anim50 = -29400
back_anim51 = -30000
back_anim52 = -30600
back_anim53 = -31200
back_anim54 = -31800
back_anim55 = -32400
back_anim56 = -33000
back_anim57 = -33600
back_anim58 = -34200
back_anim59 = -34800
back_anim60 = -35400
back_anim61 = -36000
back_anim62 = -36600
back_anim63 = -37200
back_anim64 = -37800
back_anim65 = -38400
back_anim66 = -39000
back_anim67 = -39600
back_anim68 = -40200
back_anim69 = -40800
back_anim70 = -41400
back_anim71 = -42000
back_anim72 = -42600
back_anim73 = -43200
back_anim74 = -43800
back_anim75 = -44400
back_anim76 = -45000
back_anim77 = -45600
back_anim78 = -46200
back_anim79 = -46800
back_anim80 = -47400
back_anim81 = -48000
back_anim82 = -48600
back_anim83 = -49200
back_anim84 = -49800
back_anim85 = -50400
back_anim86 = -51000
back_anim87 = -51600
back_anim88 = -52200
back_anim89 = -52800
back_anim90 = -53400
back_anim91 = -54000
back_anim92 = -54600
back_anim93 = -55200
back_anim94 = -55800
back_anim95 = -56400
back_anim96 = -57000
back_anim97 = -57600
back_anim98 = -58200
back_anim99 = -58800
back_anim100 = -59400
line = pygame.image.load('line.png').convert_alpha()
line_anim = 0
line_anim2 = 600
line_anim3 = 1200
line_anim4 = 1800
line_anim5 = 2400
line_anim6 = 3000
line_anim7 = 3600
line_anim8 = 4200
line_anim9 = 4800
line_anim10 = 5400
line_anim11 = 6000
line_anim12 = 6600
line_anim13 = 7200
line_anim14 = 7800
line_anim15 = 8400
line_anim16 = 9000
line_anim17 = 9600
line_anim18 = 10200
line_anim19 = 10800
line_anim20 = 11400
line_anim21 = 12000
line_anim22 = 12600
line_anim23 = 13200
line_anim24 = 13800
line_anim25 = 14400
line_anim26 = 15000
line_anim27 = 15600
line_anim28 = 16200
line_anim29 = 16800
line_anim30 = 17400
line_anim31 = 18000
line_anim32 = 18600
line_anim33 = 19200
line_anim34 = 19800
line_anim35 = 20400
line_anim36 = 21000
line_anim37 = 21600
line_anim38 = 22200
line_anim39 = 22800
line_anim40 = 23400
line_anim41 = 24000
line_anim42 = 24600
line_anim43 = 25200
line_anim44 = 25800
line_anim45 = 26400
line_anim46 = 27000
line_anim47 = 27600
line_anim48 = 28200
line_anim49 = 28800
line_anim50 = 29400
line_anim51 = 30000
line_anim52 = 30600
line_anim53 = 31200
line_anim54 = 31800
line_anim55 = 32400
line_anim56 = 33000
line_anim57 = 33600
line_anim58 = 34200
line_anim59 = 34800
line_anim60 = 35400
line_anim61 = 36000
line_anim62 = 36600
line_anim63 = 37200
line_anim64 = 37800
line_anim65 = 38400
line_anim66 = 39000
line_anim67 = 39600
line_anim68 = 40200
line_anim69 = 40800
line_anim70 = 41400
line_anim71 = 42000
line_anim72 = 42600
line_anim73 = 43200
line_anim74 = 43800
line_anim75 = 44400
line_anim76 = 45000
line_anim77 = 45600
line_anim78 = 46200
line_anim79 = 46800
line_anim80 = 47400
line_anim81 = 48000
line_anim82 = 48600
line_anim83 = 49200
line_anim84 = 49800
line_anim85 = 50400
line_anim86 = 51000
line_anim87 = 51600
line_anim88 = 52200
line_anim89 = 52800
line_anim90 = 53400
line_anim91 = 54000
line_anim92 = 54600
line_anim93 = 55200
line_anim94 = 55800
line_anim95 = 56400
line_anim96 = 57000
line_anim97 = 57600
line_anim98 = 58200
line_anim99 = 58800
line_anim100 = 59400
obs = pygame.image.load('obs.png').convert_alpha()

counting = 0
cactus_escaped = 0
black_color = (0, 0, 0)
arial = pygame.font.SysFont("Arial", 35, 1, 1)
temp = arial.render("0", 1, black_color)

def incrementeTime():
    global counting, temp
    counting = counting + 0.02
    if counting<0.00001:
        temp = arial.render("0", 1, black_color)
    elif counting>0.00001:
        temp = arial.render(str(counting) + "", 1, black_color)
        
def score():
    global counting
    print("STATISTIQUES :")
    print("- ", counting, " secondes")
    print("- ", cactus_escaped, " obstacles esquivés")
        
cactus_anim_x = 200
cactus_anim_x2 = 600
cactus_anim_x3 = 1000
cactus_anim_x4 = 1600
cactus_anim_x5 = 2000
cactus_anim_x6 = 2400
cactus_anim_x7 = 2800
cactus_anim_x8 = 3200
cactus_anim_x9 = 3600
cactus_anim_x10 = 4400
cactus_anim_x11 = 4800
cactus_anim_x12 = 5200
cactus_anim_x13 = 5600
cactus_anim_x14 = 6000
cactus_anim_x15 = 6400
cactus_anim_x16 = 7000
cactus_anim_x17 = 7400
cactus_anim_x18 = 7800
cactus_anim_x19 = 8600
cactus_anim_x20 = 9000
cactus_anim_x21 = 4800
cactus_anim_x22 = 5200
cactus_anim_x23 = 5600
cactus_anim_x24 = 6000
cactus_anim_x25 = 6400
cactus_anim_x26 = 7000
cactus_anim_x27 = 7400
cactus_anim_x28 = 7800
cactus_anim_x29 = 8600
cactus_anim_x30 = 9000
cactus_anim_x31 = 9400
cactus_anim_x32 = 9800
cactus_anim_x33 = 10200
cactus_anim_x34 = 10600
cactus_anim_x35 = 11000
cactus_anim_x36 = 11400
cactus_anim_x37 = 11800
cactus_anim_x38 = 12200
cactus_anim_x39 = 13000
cactus_anim_x40 = 13400
cactus_anim_x41 = 13800
cactus_anim_x42 = 14200
cactus_anim_x43 = 14600
cactus_anim_x44 = 14800
cactus_anim_x45 = 15200
cactus_anim_x46 = 15600
cactus_anim_x47 = 16200
cactus_anim_x48 = 16600
cactus_anim_x49 = 17000
cactus_anim_x50 = 17400
text = font.render('a', False, 'Red')

player_rect = player.get_rect(center=(player_anim_x, player_anim_y))

y_gravity=1
jump_height=20
y_velocity=jump_height

while True:

    incrementeTime()

    back_anim = back_anim + 5
    back_anim2 = back_anim2 + 5
    back_anim3 = back_anim3 + 5
    back_anim4 = back_anim4 + 5
    back_anim5 = back_anim5 + 5
    back_anim6 = back_anim6 + 5
    back_anim7 = back_anim7 + 5
    back_anim8 = back_anim8 + 5
    back_anim9 = back_anim9 + 5
    back_anim10 = back_anim10 + 5
    back_anim11 = back_anim11 + 5
    back_anim12 = back_anim12 + 5
    back_anim13 = back_anim13 + 5
    back_anim14 = back_anim14 + 5
    back_anim15 = back_anim15 + 5
    back_anim16 = back_anim16 + 5
    back_anim17 = back_anim17 + 5
    back_anim18 = back_anim18 + 5
    back_anim19 = back_anim19 + 5
    back_anim20 = back_anim20 + 5
    back_anim21 = back_anim21 + 5
    back_anim22 = back_anim22 + 5
    back_anim23 = back_anim23 + 5
    back_anim24 = back_anim24 + 5
    back_anim25 = back_anim25 + 5
    back_anim26 = back_anim26 + 5
    back_anim27 = back_anim27 + 5
    back_anim28 = back_anim28 + 5
    back_anim29 = back_anim29 + 5
    back_anim30 = back_anim30 + 5
    back_anim31 = back_anim31 + 5
    back_anim32 = back_anim32 + 5
    back_anim33 = back_anim33 + 5
    back_anim34 = back_anim34 + 5
    back_anim35 = back_anim35 + 5
    back_anim36 = back_anim36 + 5
    back_anim37 = back_anim37 + 5
    back_anim38 = back_anim38 + 5
    back_anim39 = back_anim39 + 5
    back_anim40 = back_anim40 + 5
    back_anim41 = back_anim41 + 5
    back_anim42 = back_anim42 + 5
    back_anim43 = back_anim43 + 5
    back_anim44 = back_anim44 + 5
    back_anim45 = back_anim45 + 5
    back_anim46 = back_anim46 + 5
    back_anim47 = back_anim47 + 5
    back_anim48 = back_anim48 + 5
    back_anim49 = back_anim49 + 5
    back_anim50 = back_anim50 + 5
    back_anim51 = back_anim51 + 5
    back_anim52 = back_anim52 + 5
    back_anim53 = back_anim53 + 5
    back_anim54 = back_anim54 + 5
    back_anim55 = back_anim55 + 5
    back_anim56 = back_anim56 + 5
    back_anim57 = back_anim57 + 5
    back_anim58 = back_anim58 + 5
    back_anim59 = back_anim59 + 5
    back_anim60 = back_anim60 + 5
    back_anim61 = back_anim61 + 5
    back_anim62 = back_anim62 + 5
    back_anim63 = back_anim63 + 5
    back_anim64 = back_anim64 + 5
    back_anim65 = back_anim65 + 5
    back_anim66 = back_anim66 + 5
    back_anim67 = back_anim67 + 5
    back_anim68 = back_anim68 + 5
    back_anim69 = back_anim69 + 5
    back_anim70 = back_anim70 + 5
    back_anim71 = back_anim71 + 5
    back_anim72 = back_anim72 + 5
    back_anim73 = back_anim73 + 5
    back_anim74 = back_anim74 + 5
    back_anim75 = back_anim75 + 5
    back_anim76 = back_anim76 + 5
    back_anim77 = back_anim77 + 5
    back_anim78 = back_anim78 + 5
    back_anim79 = back_anim79 + 5
    back_anim80 = back_anim80 + 5
    back_anim81 = back_anim81 + 5
    back_anim82 = back_anim82 + 5
    back_anim83 = back_anim83 + 5
    back_anim84 = back_anim84 + 5
    back_anim85 = back_anim85 + 5
    back_anim86 = back_anim86 + 5
    back_anim87 = back_anim87 + 5
    back_anim88 = back_anim88 + 5
    back_anim89 = back_anim89 + 5
    back_anim90 = back_anim90 + 5
    back_anim91 = back_anim91 + 5
    back_anim92 = back_anim92 + 5
    back_anim93 = back_anim93 + 5
    back_anim94 = back_anim94 + 5
    back_anim95 = back_anim95 + 5
    back_anim96 = back_anim96 + 5
    back_anim97 = back_anim97 + 5
    back_anim98 = back_anim98 + 5
    back_anim99 = back_anim99 + 5
    back_anim100 = back_anim100 + 5
    line_anim = line_anim - 5
    line_anim2 = line_anim2 - 5
    line_anim3 = line_anim3 - 5
    line_anim4 = line_anim4 - 5
    line_anim5 = line_anim5 - 5
    line_anim6 = line_anim6 - 5
    line_anim7 = line_anim7 - 5
    line_anim8 = line_anim8 - 5
    line_anim9 = line_anim9 - 5
    line_anim10 = line_anim10 - 5
    line_anim11 = line_anim11 - 5
    line_anim12 = line_anim12 - 5
    line_anim13 = line_anim13 - 5
    line_anim14 = line_anim14 - 5
    line_anim15 = line_anim15 - 5
    line_anim16 = line_anim16 - 5
    line_anim17 = line_anim17 - 5
    line_anim18 = line_anim18 - 5
    line_anim19 = line_anim19 - 5
    line_anim20 = line_anim20 - 5
    line_anim21 = line_anim21 - 5
    line_anim22 = line_anim22 - 5
    line_anim23 = line_anim23 - 5
    line_anim24 = line_anim24 - 5
    line_anim25 = line_anim25 - 5
    line_anim26 = line_anim26 - 5
    line_anim27 = line_anim27 - 5
    line_anim28 = line_anim28 - 5
    line_anim29 = line_anim29 - 5
    line_anim30 = line_anim30 - 5
    line_anim31 = line_anim31 - 5
    line_anim32 = line_anim32 - 5
    line_anim33 = line_anim33 - 5
    line_anim34 = line_anim34 - 5
    line_anim35 = line_anim35 - 5
    line_anim36 = line_anim36 - 5
    line_anim37 = line_anim37 - 5
    line_anim38 = line_anim38 - 5
    line_anim39 = line_anim39 - 5
    line_anim40 = line_anim40 - 5
    line_anim41 = line_anim41 - 5
    line_anim42 = line_anim42 - 5
    line_anim43 = line_anim43 - 5
    line_anim44 = line_anim44 - 5
    line_anim45 = line_anim45 - 5
    line_anim46 = line_anim46 - 5
    line_anim47 = line_anim47 - 5
    line_anim48 = line_anim48 - 5
    line_anim49 = line_anim49 - 5
    line_anim50 = line_anim50 - 5
    line_anim51 = line_anim51 - 5
    line_anim52 = line_anim52 - 5
    line_anim53 = line_anim53 - 5
    line_anim54 = line_anim54 - 5
    line_anim55 = line_anim55 - 5
    line_anim56 = line_anim56 - 5
    line_anim57 = line_anim57 - 5
    line_anim58 = line_anim58 - 5
    line_anim59 = line_anim59 - 5
    line_anim60 = line_anim60 - 5
    line_anim61 = line_anim61 - 5
    line_anim62 = line_anim62 - 5
    line_anim63 = line_anim63 - 5
    line_anim64 = line_anim64 - 5
    line_anim65 = line_anim65 - 5
    line_anim66 = line_anim66 - 5
    line_anim67 = line_anim67 - 5
    line_anim68 = line_anim68 - 5
    line_anim69 = line_anim69 - 5
    line_anim70 = line_anim70 - 5
    line_anim71 = line_anim71 - 5
    line_anim72 = line_anim72 - 5
    line_anim73 = line_anim73 - 5
    line_anim74 = line_anim74 - 5
    line_anim75 = line_anim75 - 5
    line_anim76 = line_anim76 - 5
    line_anim77 = line_anim77 - 5
    line_anim78 = line_anim78 - 5
    line_anim79 = line_anim79 - 5
    line_anim80 = line_anim80 - 5
    line_anim81 = line_anim81 - 5
    line_anim82 = line_anim82 - 5
    line_anim83 = line_anim83 - 5
    line_anim84 = line_anim84 - 5
    line_anim85 = line_anim85 - 5
    line_anim86 = line_anim86 - 5
    line_anim87 = line_anim87 - 5
    line_anim88 = line_anim88 - 5
    line_anim89 = line_anim89 - 5
    line_anim90 = line_anim90 - 5
    line_anim91 = line_anim91 - 5
    line_anim92 = line_anim92 - 5
    line_anim93 = line_anim93 - 5
    line_anim94 = line_anim94 - 5
    line_anim95 = line_anim95 - 5
    line_anim96 = line_anim96 - 5
    line_anim97 = line_anim97 - 5
    line_anim98 = line_anim98 - 5
    line_anim99 = line_anim99 - 5
    line_anim100 = line_anim100 - 5
    cactus_anim_x = cactus_anim_x - 5
    cactus_anim_x2 = cactus_anim_x2 - 5
    cactus_anim_x3 = cactus_anim_x3 - 5
    cactus_anim_x4 = cactus_anim_x4 - 5
    cactus_anim_x5 = cactus_anim_x5 - 5
    cactus_anim_x6 = cactus_anim_x6 - 5
    cactus_anim_x7 = cactus_anim_x7 - 5
    cactus_anim_x8 = cactus_anim_x8 - 5
    cactus_anim_x9 = cactus_anim_x9 - 5
    cactus_anim_x10 = cactus_anim_x10 - 5
    cactus_anim_x11 = cactus_anim_x11 - 5
    cactus_anim_x12 = cactus_anim_x12 - 5
    cactus_anim_x13 = cactus_anim_x13 - 5
    cactus_anim_x14 = cactus_anim_x14 - 5
    cactus_anim_x15 = cactus_anim_x15 - 5
    cactus_anim_x16 = cactus_anim_x16 - 5
    cactus_anim_x17 = cactus_anim_x17 - 5
    cactus_anim_x18 = cactus_anim_x18 - 5
    cactus_anim_x19 = cactus_anim_x19 - 5
    cactus_anim_x20 = cactus_anim_x20 - 5
    cactus_anim_x21 = cactus_anim_x21 - 5
    cactus_anim_x22 = cactus_anim_x22 - 5
    cactus_anim_x23 = cactus_anim_x23 - 5
    cactus_anim_x24 = cactus_anim_x24 - 5
    cactus_anim_x25 = cactus_anim_x25 - 5
    cactus_anim_x26 = cactus_anim_x26 - 5
    cactus_anim_x27 = cactus_anim_x27 - 5
    cactus_anim_x28 = cactus_anim_x28 - 5
    cactus_anim_x29 = cactus_anim_x29 - 5
    cactus_anim_x30 = cactus_anim_x30 - 5
    cactus_anim_x31 = cactus_anim_x31 - 5
    cactus_anim_x32 = cactus_anim_x32 - 5
    cactus_anim_x33 = cactus_anim_x33 - 5
    cactus_anim_x34 = cactus_anim_x34 - 5
    cactus_anim_x35 = cactus_anim_x35 - 5
    cactus_anim_x36 = cactus_anim_x36 - 5
    cactus_anim_x37 = cactus_anim_x37 - 5
    cactus_anim_x38 = cactus_anim_x38 - 5
    cactus_anim_x39 = cactus_anim_x39 - 5
    cactus_anim_x40 = cactus_anim_x40 - 5
    cactus_anim_x41 = cactus_anim_x41 - 5
    cactus_anim_x42 = cactus_anim_x42 - 5
    cactus_anim_x43 = cactus_anim_x43 - 5
    cactus_anim_x44 = cactus_anim_x44 - 5
    cactus_anim_x45 = cactus_anim_x45 - 5
    cactus_anim_x46 = cactus_anim_x46 - 5
    cactus_anim_x47 = cactus_anim_x47 - 5
    cactus_anim_x48 = cactus_anim_x48 - 5
    cactus_anim_x49 = cactus_anim_x49 - 5
    cactus_anim_x50 = cactus_anim_x50 - 5
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                jumping = True
    screen.blit(background, (back_anim, 0))
    screen.blit(background, (back_anim2, 0))
    screen.blit(background, (back_anim3, 0))
    screen.blit(background, (back_anim4, 0))
    screen.blit(background, (back_anim5, 0))
    screen.blit(background, (back_anim6, 0))
    screen.blit(background, (back_anim7, 0))
    screen.blit(background, (back_anim8, 0))
    screen.blit(background, (back_anim9, 0))
    screen.blit(background, (back_anim10, 0))
    screen.blit(background, (back_anim11, 0))
    screen.blit(background, (back_anim12, 0))
    screen.blit(background, (back_anim13, 0))
    screen.blit(background, (back_anim14, 0))
    screen.blit(background, (back_anim15, 0))
    screen.blit(background, (back_anim16, 0))
    screen.blit(background, (back_anim17, 0))
    screen.blit(background, (back_anim18, 0))
    screen.blit(background, (back_anim19, 0))
    screen.blit(background, (back_anim20, 0))
    screen.blit(background, (back_anim21, 0))
    screen.blit(background, (back_anim22, 0))
    screen.blit(background, (back_anim23, 0))
    screen.blit(background, (back_anim24, 0))
    screen.blit(background, (back_anim25, 0))
    screen.blit(background, (back_anim26, 0))
    screen.blit(background, (back_anim27, 0))
    screen.blit(background, (back_anim28, 0))
    screen.blit(background, (back_anim29, 0))
    screen.blit(background, (back_anim30, 0))
    screen.blit(background, (back_anim31, 0))
    screen.blit(background, (back_anim32, 0))
    screen.blit(background, (back_anim33, 0))
    screen.blit(background, (back_anim34, 0))
    screen.blit(background, (back_anim35, 0))
    screen.blit(background, (back_anim36, 0))
    screen.blit(background, (back_anim37, 0))
    screen.blit(background, (back_anim38, 0))
    screen.blit(background, (back_anim39, 0))
    screen.blit(background, (back_anim40, 0))
    screen.blit(background, (back_anim41, 0))
    screen.blit(background, (back_anim42, 0))
    screen.blit(background, (back_anim43, 0))
    screen.blit(background, (back_anim44, 0))
    screen.blit(background, (back_anim45, 0))
    screen.blit(background, (back_anim46, 0))
    screen.blit(background, (back_anim47, 0))
    screen.blit(background, (back_anim48, 0))
    screen.blit(background, (back_anim49, 0))
    screen.blit(background, (back_anim50, 0))
    screen.blit(background, (back_anim51, 0))
    screen.blit(background, (back_anim52, 0))
    screen.blit(background, (back_anim53, 0))
    screen.blit(background, (back_anim54, 0))
    screen.blit(background, (back_anim55, 0))
    screen.blit(background, (back_anim56, 0))
    screen.blit(background, (back_anim57, 0))
    screen.blit(background, (back_anim58, 0))
    screen.blit(background, (back_anim59, 0))
    screen.blit(background, (back_anim60, 0))
    screen.blit(background, (back_anim61, 0))
    screen.blit(background, (back_anim62, 0))
    screen.blit(background, (back_anim63, 0))
    screen.blit(background, (back_anim64, 0))
    screen.blit(background, (back_anim65, 0))
    screen.blit(background, (back_anim66, 0))
    screen.blit(background, (back_anim67, 0))
    screen.blit(background, (back_anim68, 0))
    screen.blit(background, (back_anim69, 0))
    screen.blit(background, (back_anim70, 0))
    screen.blit(background, (back_anim71, 0))
    screen.blit(background, (back_anim72, 0))
    screen.blit(background, (back_anim73, 0))
    screen.blit(background, (back_anim74, 0))
    screen.blit(background, (back_anim75, 0))
    screen.blit(background, (back_anim76, 0))
    screen.blit(background, (back_anim77, 0))
    screen.blit(background, (back_anim78, 0))
    screen.blit(background, (back_anim79, 0))
    screen.blit(background, (back_anim80, 0))
    screen.blit(background, (back_anim81, 0))
    screen.blit(background, (back_anim82, 0))
    screen.blit(background, (back_anim83, 0))
    screen.blit(background, (back_anim84, 0))
    screen.blit(background, (back_anim85, 0))
    screen.blit(background, (back_anim86, 0))
    screen.blit(background, (back_anim87, 0))
    screen.blit(background, (back_anim88, 0))
    screen.blit(background, (back_anim89, 0))
    screen.blit(background, (back_anim90, 0))
    screen.blit(background, (back_anim91, 0))
    screen.blit(background, (back_anim92, 0))
    screen.blit(background, (back_anim93, 0))
    screen.blit(background, (back_anim94, 0))
    screen.blit(background, (back_anim95, 0))
    screen.blit(background, (back_anim96, 0))
    screen.blit(background, (back_anim97, 0))
    screen.blit(background, (back_anim98, 0))
    screen.blit(background, (back_anim99, 0))
    screen.blit(background, (back_anim100, 0))
    screen.blit(line, (line_anim, 270))
    screen.blit(line, (line_anim2, 270))
    screen.blit(line, (line_anim3, 270))
    screen.blit(line, (line_anim4, 270))
    screen.blit(line, (line_anim5, 270))
    screen.blit(line, (line_anim6, 270))
    screen.blit(line, (line_anim7, 270))
    screen.blit(line, (line_anim8, 270))
    screen.blit(line, (line_anim9, 270))
    screen.blit(line, (line_anim10, 270))
    screen.blit(line, (line_anim11, 270))
    screen.blit(line, (line_anim12, 270))
    screen.blit(line, (line_anim13, 270))
    screen.blit(line, (line_anim14, 270))
    screen.blit(line, (line_anim15, 270))
    screen.blit(line, (line_anim16, 270))
    screen.blit(line, (line_anim17, 270))
    screen.blit(line, (line_anim18, 270))
    screen.blit(line, (line_anim19, 270))
    screen.blit(line, (line_anim20, 270))
    screen.blit(line, (line_anim21, 270))
    screen.blit(line, (line_anim22, 270))
    screen.blit(line, (line_anim23, 270))
    screen.blit(line, (line_anim24, 270))
    screen.blit(line, (line_anim25, 270))
    screen.blit(line, (line_anim26, 270))
    screen.blit(line, (line_anim27, 270))
    screen.blit(line, (line_anim28, 270))
    screen.blit(line, (line_anim29, 270))
    screen.blit(line, (line_anim30, 270))
    screen.blit(line, (line_anim31, 270))
    screen.blit(line, (line_anim32, 270))
    screen.blit(line, (line_anim33, 270))
    screen.blit(line, (line_anim34, 270))
    screen.blit(line, (line_anim35, 270))
    screen.blit(line, (line_anim36, 270))
    screen.blit(line, (line_anim37, 270))
    screen.blit(line, (line_anim38, 270))
    screen.blit(line, (line_anim39, 270))
    screen.blit(line, (line_anim40, 270))
    screen.blit(line, (line_anim41, 270))
    screen.blit(line, (line_anim42, 270))
    screen.blit(line, (line_anim43, 270))
    screen.blit(line, (line_anim44, 270))
    screen.blit(line, (line_anim45, 270))
    screen.blit(line, (line_anim46, 270))
    screen.blit(line, (line_anim47, 270))
    screen.blit(line, (line_anim48, 270))
    screen.blit(line, (line_anim49, 270))
    screen.blit(line, (line_anim50, 270))
    screen.blit(line, (line_anim51, 270))
    screen.blit(line, (line_anim52, 270))
    screen.blit(line, (line_anim53, 270))
    screen.blit(line, (line_anim54, 270))
    screen.blit(line, (line_anim55, 270))
    screen.blit(line, (line_anim56, 270))
    screen.blit(line, (line_anim57, 270))
    screen.blit(line, (line_anim58, 270))
    screen.blit(line, (line_anim59, 270))
    screen.blit(line, (line_anim60, 270))
    screen.blit(line, (line_anim61, 270))
    screen.blit(line, (line_anim62, 270))
    screen.blit(line, (line_anim63, 270))
    screen.blit(line, (line_anim64, 270))
    screen.blit(line, (line_anim65, 270))
    screen.blit(line, (line_anim66, 270))
    screen.blit(line, (line_anim67, 270))
    screen.blit(line, (line_anim68, 270))
    screen.blit(line, (line_anim69, 270))
    screen.blit(line, (line_anim70, 270))
    screen.blit(line, (line_anim71, 270))
    screen.blit(line, (line_anim72, 270))
    screen.blit(line, (line_anim73, 270))
    screen.blit(line, (line_anim74, 270))
    screen.blit(line, (line_anim75, 270))
    screen.blit(line, (line_anim76, 270))
    screen.blit(line, (line_anim77, 270))
    screen.blit(line, (line_anim78, 270))
    screen.blit(line, (line_anim79, 270))
    screen.blit(line, (line_anim80, 270))
    screen.blit(line, (line_anim81, 270))
    screen.blit(line, (line_anim82, 270))
    screen.blit(line, (line_anim83, 270))
    screen.blit(line, (line_anim84, 270))
    screen.blit(line, (line_anim85, 270))
    screen.blit(line, (line_anim86, 270))
    screen.blit(line, (line_anim87, 270))
    screen.blit(line, (line_anim88, 270))
    screen.blit(line, (line_anim89, 270))
    screen.blit(line, (line_anim90, 270))
    screen.blit(line, (line_anim91, 270))
    screen.blit(line, (line_anim92, 270))
    screen.blit(line, (line_anim93, 270))
    screen.blit(line, (line_anim94, 270))
    screen.blit(line, (line_anim95, 270))
    screen.blit(line, (line_anim96, 270))
    screen.blit(line, (line_anim97, 270))
    screen.blit(line, (line_anim98, 270))
    screen.blit(line, (line_anim99, 270))
    screen.blit(line, (line_anim100, 270))
    screen.blit(obs, (cactus_anim_x, 142))
    screen.blit(obs, (cactus_anim_x2, 142))
    screen.blit(obs, (cactus_anim_x3, 142))
    screen.blit(obs, (cactus_anim_x4, 142))
    screen.blit(obs, (cactus_anim_x5, 142))
    screen.blit(obs, (cactus_anim_x6, 142))
    screen.blit(obs, (cactus_anim_x7, 142))
    screen.blit(obs, (cactus_anim_x8, 142))
    screen.blit(obs, (cactus_anim_x9, 142))
    screen.blit(obs, (cactus_anim_x10, 142))
    screen.blit(obs, (cactus_anim_x11, 142))
    screen.blit(obs, (cactus_anim_x12, 142))
    screen.blit(obs, (cactus_anim_x13, 142))
    screen.blit(obs, (cactus_anim_x14, 142))
    screen.blit(obs, (cactus_anim_x15, 142))
    screen.blit(obs, (cactus_anim_x16, 142))
    screen.blit(obs, (cactus_anim_x17, 142))
    screen.blit(obs, (cactus_anim_x18, 142))
    screen.blit(obs, (cactus_anim_x19, 142))
    screen.blit(obs, (cactus_anim_x20, 142))
    screen.blit(obs, (cactus_anim_x21, 142))
    screen.blit(obs, (cactus_anim_x22, 142))
    screen.blit(obs, (cactus_anim_x23, 142))
    screen.blit(obs, (cactus_anim_x24, 142))
    screen.blit(obs, (cactus_anim_x25, 142))
    screen.blit(obs, (cactus_anim_x26, 142))
    screen.blit(obs, (cactus_anim_x27, 142))
    screen.blit(obs, (cactus_anim_x28, 142))
    screen.blit(obs, (cactus_anim_x29, 142))
    screen.blit(obs, (cactus_anim_x30, 142))
    screen.blit(obs, (cactus_anim_x31, 142))
    screen.blit(obs, (cactus_anim_x32, 142))
    screen.blit(obs, (cactus_anim_x33, 142))
    screen.blit(obs, (cactus_anim_x34, 142))
    screen.blit(obs, (cactus_anim_x35, 142))
    screen.blit(obs, (cactus_anim_x36, 142))
    screen.blit(obs, (cactus_anim_x37, 142))
    screen.blit(obs, (cactus_anim_x38, 142))
    screen.blit(obs, (cactus_anim_x39, 142))
    screen.blit(obs, (cactus_anim_x40, 142))
    screen.blit(obs, (cactus_anim_x41, 142))
    screen.blit(obs, (cactus_anim_x42, 142))
    screen.blit(obs, (cactus_anim_x43, 142))
    screen.blit(obs, (cactus_anim_x44, 142))
    screen.blit(obs, (cactus_anim_x45, 142))
    screen.blit(obs, (cactus_anim_x46, 142))
    screen.blit(obs, (cactus_anim_x47, 142))
    screen.blit(obs, (cactus_anim_x48, 142))
    screen.blit(obs, (cactus_anim_x49, 142))
    screen.blit(obs, (cactus_anim_x50, 142))
    screen.blit(temp, (480, 20))
    screen.blit(text, (0, 675))

    if jumping:
        player_anim_y -= y_velocity
        y_velocity -= y_gravity
        if y_velocity < -jump_height:
            jumping = False
            y_velocity = jump_height
        player_rect = player.get_rect(center=(player_anim_x, player_anim_y))
        screen.blit(player, player_rect)
    else:
        player_rect = player.get_rect(center=(player_anim_x, player_anim_y))
        screen.blit(player, player_rect)
        
    pygame.display.update()
    eta.tick(60)
    if cactus_anim_x == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x2 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == player_anim_x and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x3 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x3 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x4 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x4 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x5 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x5 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x6 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x6 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x7 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x7 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x8 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x8 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x9 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x9 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
        
    if cactus_anim_x10 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x10 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x10 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x11 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x11 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x12 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x12 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x13 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x13 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x14 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x14 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x15 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x15 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x16 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x16 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x17 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x17 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x18 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x18 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x19 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x19 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
        
    if cactus_anim_x20 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x20 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x20 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x21 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x21 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x22 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x22 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x23 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x23 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x24 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x24 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x25 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x25 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x26 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x26 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x27 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x27 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x28 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x28 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x29 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x29 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
        
    if cactus_anim_x30 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x30 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x30 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x31 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x31 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x32 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x32 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x33 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x33 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x34 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x34 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x35 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x35 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x36 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x36 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x37 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x37 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x38 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x38 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x39 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x39 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
        
    if cactus_anim_x40 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x40 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x40 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x41 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x41 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x42 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x42 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x43 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x43 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x44 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x44 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x45 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x45 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x46 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x46 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x47 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x47 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x48 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x48 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x49 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x49 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
        
    if cactus_anim_x50 == 45 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 220:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 200:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 181:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 163:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 146:
        time.sleep(0.5)
        score()
    elif cactus_anim_x50 == -20 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 146:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 130:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 45 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 40 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 35 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == 0 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -5 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -10 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -15 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -20 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -25 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()
    elif cactus_anim_x50 == -30 and player_anim_y == 115:
        time.sleep(0.5)
        score()
        pygame.quit()
        exit()

    if cactus_anim_x == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x2 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x3 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x4 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x5 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x6 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x7 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x8 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x9 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x10 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x11 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x12 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x13 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x14 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x15 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x16 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x17 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x18 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x19 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x20 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x21 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x22 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x23 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x24 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x25 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x26 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x27 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x28 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x29 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x30 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x31 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x32 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x33 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x34 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x35 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x36 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x37 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x38 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x39 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x40 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x41 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x42 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x43 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x44 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x45 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x46 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x47 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x48 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x49 == -80:
        cactus_escaped = cactus_escaped + 1
    elif cactus_anim_x50 == -80:
        cactus_escaped = cactus_escaped + 1
