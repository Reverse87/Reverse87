import tkinter
from tkinter.font import Font
import random

def incrementeTime():
    global compteur
    compteur=compteur+1
    if compteur<10:
        temp['text']="000"+str(compteur)
    elif compteur>=10 and compteur<100:
        temp['text']="00"+str(compteur)
    elif compteur>=100 and compteur<1000:
        temp['text']="0"+str(compteur)
    else:
        temp['text']=str(compteur)

    if flag:
        fen.after(150, incrementeTime)

def courrir():
    global frame, photo, saut, y, flag
    photo=tkinter.PhotoImage(file=str(frame)+'.png')
    if saut==0:
        canvas.create_image(120, y, image=photo)
        frame+=1

        if frame>2:
            frame=1

        if flag:
            fen.after(150, courrir)

def sauter():
    global saut, photo2, y, dt1, flag
    saut=1
    photo2=tkinter.PhotoImage(file="2.png")
    if flag:
        y=y+dt1;
        if y>215:
            y, dt1, saut=236, -25, 0
            courrir()
        if y<130:
            y, dt1=140, 25
        else:
            p2=canvas.create_image(120, y, image=photo2)
            return "Saut impossible"
        if saut:
            canvas.create_image(120, y, image=photo2)
            fen.after(150, sauter)

def position():
    for i in range(1,50):
        pos.append(pos[i-1]+random.choice([0, 300, 500]))

def obstacle():
    global y, flag, obs, pos, dt2, b2, rep
    obs=tkinter.PhotoImage(file="obs.png")
    for i in range(len(pos)):
        canvas.create_image(pos[i], 210, image=obs)
        x1=pos[i]-50
        pos[i]-=dt2
        if(x1<122 and pos[i]>90 and y<=236 and y>165):
            stop()
            b2=tkinter.Button(fen, text="Rejouer", command="", font=font, bg="#f00ab7")
            rep = tkinter.Label(canvas, text="Oupps, Vous avez perdu !")
            b2.place(relx=0.4, rely=0.4)
            rep.place(relx=0.3, rely=0.2)
    canvas.create_line(0, 275, 600, 275, width=2)
    if flag:
        fen.after(50, obstacle)

def stop():
    global flag
    flag = 0

def replay():
    global y, saut, frame, dt1, dt2, flag, pos, b2, rep
    y, frame, dt1, dt2, saut, flag, pos, compteur=236, 1, -25, 15, 0, 1, [600], 0
    canvas.delete(p2)
    b2.destroy()
    jeu()

y, frame, dt1, dt2, saut, flag, pos, compteur=236, 1, -25, 15, 0, 1, [600], 0

def jeu():
    position()
    courrir()
    sauter()
    obstacle()
    incrementeTime()

fen=tkinter.Tk()
fondImage=tkinter.PhotoImage(file="fondjeux2.png")
canvas=tkinter.Canvas(fen, width=600, height=300)
font=Font(size=12, weight='bold')
b1=tkinter.Button(fen, text="Sauter", command=sauter, font=font, bg="#f00ab7")
canvas.pack(padx=5, pady=5)
canvas.create_image(150, 100, image=fondImage)
temp=tkinter.Label(fen, font=font, bg="#f00ab7")
b1.pack()
temp.place(relx=0.9, rely=0.1)
jeu()
fen.mainloop()
                        
